<?php

namespace Mpdf\Tag;

class U extends InlineTag
{


}
